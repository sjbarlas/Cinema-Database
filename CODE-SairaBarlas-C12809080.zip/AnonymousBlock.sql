-- Anonymous block for the Procedure
SET serveroutput ON;
DECLARE
  mv_name REVIEWER.MOVIENAME%TYPE:='&Enter_movie_name';
  priority_rating REVIEWER.PRIORITYRATING%TYPE:='&Enter_reviewer_priority_rating';
  mv_id MOVIE.MOVIEID%TYPE;  
BEGIN
  add_priority_rating_reviewer(mv_name, priority_rating);
END;